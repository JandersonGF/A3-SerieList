package model;

public enum Status {
	QUERO_ASSISTIR,
	ASSISTINDO,
	CONCLUIDA;
}
